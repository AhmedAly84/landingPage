/**
 * Define Global Variables
 * 
*/
const allSection = document.querySelectorAll('section');
const list = document.querySelector('#navbar__list');
const navbar =document.querySelector('nav');
const divCounter = document.getElementsByClassName('landing__container').length;
const fragment = document.createDocumentFragment();
let isScroll = false;
let interval = null;    
const topBtn = document.getElementById('top');
/***Build Nav  */
allSection.forEach(allSection => {
    const listItem = document.createElement('li');
    const listItemLink =document.createElement('a');
    const linkData = allSection.getAttribute('data-nav');
    const linkText = document.createTextNode(linkData);
    const sectionId = allSection.getAttribute('id');
          listItemLink.setAttribute('href', '#' + sectionId);
          listItemLink.setAttribute('id', 'link-' + sectionId);
          listItemLink.classList.add('menu__link');
//append the element to thier parents
listItem.appendChild(listItemLink);
listItemLink.appendChild(linkText);
fragment.appendChild(listItem);

listItemLink.addEventListener('click', function() {
    allSection.scrollIntoView({behavior: "smooth"});
});
list.appendChild(fragment);
});


function startHideNav(func, time) {
    interval = setInterval(func, time);
}

//function to navbar show
function stopHideNav() {
    clearInterval(interval);
    navbar.style.display='block';
}
// functiom to show the go to top btn
function showTopBtn(){
    if (window.pageYOffset >=400){
        topBtn.style.display='block';
    }
    else {
        topBtn.style.display ='none';
    }
}
// function to find section possation
const posation = function () {
    const sectionCheck = document.querySelectorAll('section');
    //looping over the sections again to find what section is active and give it the ‘your-active-class’ style
    sectionCheck.forEach(section => {
       
        const sectionRect = section.getBoundingClientRect();
       if(
           sectionRect.top  <=50  && sectionRect.top  >=-50 &&
           sectionRect.right <= (window.innerWidth || document.documentElement.clientWidth)
        )
       {
        sectionCheck.forEach((section) => {
            section.classList.remove('your-active-class');
        });
             section.classList.add('your-active-class');
             toActiveLink(section);
       };
    });
};

// function to active the link of reading section
function toActiveLink(actvSection)  {
    let actvLnks = document.querySelectorAll('a');
    let sectionData = actvSection.getAttribute("data-nav");
    
    for (actvLnk of actvLnks) {
        if (actvLnk.textContent === sectionData) {
            actvLnk.classList.add("active_link");
        } else {
            actvLnk.classList.remove("active_link");
        }
    }
 
 };

window.addEventListener('load',()=>{
    
    startHideNav(setInterval(() => {
        navbar.style.display='none';
    },5000));

//    //  remove active class on load
    allSection.forEach(section=>{
        section.classList.remove('your-active-class');
    });
});




//scroll to top
topBtn.addEventListener('click',(e)=>{
    e.preventDefault();
    window.scrollTo(0,0);
//   
});

window.addEventListener(
    'scroll',
    function (e) {
        e.preventDefault();
        posation();
        showTopBtn();
        stopHideNav() ;
       
       

    },
    false
);


