# landingPage

Udacity-project1

## languages have you used in this project

- [HTML](#index)
- [CSS](#style)
- [JavaScript](#script)

## learned during the implementation of this project

The following is a list of the courses associated with the Front End Nanodegree.

- CSS, Website Layout, Website Components
- JavaScript & The DOM

## resources used

See below for the Udacity Style Guide used thoroughout the Front End Nanodegree.

- [Nanodegree Style Guide](http://udacity.github.io/frontend-nanodegree-styleguide/)
